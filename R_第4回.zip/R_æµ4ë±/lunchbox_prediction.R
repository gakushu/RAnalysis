# パッケージの読み込み
library(ggplot2)
library(dplyr)

# データの読み込み
# mac OSの場合
train=read.csv('train.csv')
# Windows OSの場合
train=read.csv('train.csv',fileEncoding="UTF-8-BOM")
train$remarks

# 空欄("")をNAに変更して読み込み
# mac OSの場合
train=read.csv('train.csv',na.strings=c("", "NULL"))
# Windows OSの場合
train=read.csv('train.csv',na.strings=c("", "NULL"),fileEncoding="UTF-8-BOM")
train$remarks

#データ構造を把握する
str(train)
View(train)
head(train)
tail(train)
class(train)
dim(train)

# y(販売数)、temperature(気温)の平均を求めてください
mean(train$y)
mean(train$temperature)

# kcal(お弁当のカロリー)の平均を求めてください
mean(train$kcal) # 「NA」が表示されます
train$kcal

# 欠損を無視してkcal(お弁当のカロリー)の平均を求める
mean(train$kcal,na.rm=TRUE)

# y(販売数)の可視化
ggplot(train,aes(x=datetime,y=y))+geom_line() # 警告が表示される

# 変数datetime（日時）変数の問題点
class(train$datetime)

# 変数datetime（日時）変数をDate（日付）型に変更
train$time=as.Date(train$datetime)
class(train$time)

# 販売数の可視化
ggplot(train,aes(x=time, y=y))+geom_line()

# 縦軸・横軸にラベルを表記
ggplot(train,aes(x=time,y=y))+
  geom_line()+
  labs(x="時間",y="販売数")+
  # 日本語の文字化けを防ぐフォント指定
  theme_gray(base_family = "HiraKakuPro-W3") 

# y(販売数)とsoldout(完売ダミー)の散布図を作成してください
ggplot(train,aes(x=soldout,y=y))+
  geom_point()+
  labs(x="sold out",y="y")

# y(販売数)とkcal（カロリー） の散布図を作成してください
ggplot(train,aes(x=kcal,y=y))+
  geom_point()+
  labs(x="kcal",y="y")

# y(販売数)とprecipitation(降水量)の散布図を作成してください
ggplot(train,aes(x=precipitation,y=y))+
  geom_point()+
  labs(x="precipitation",y="y")

# y(販売数)とpayday(給料日ダミー) の散布図を作成してください
ggplot(train,aes(x=factor(payday),y=y))+
  geom_point()+
  labs(x="payday",y="y")

#y(販売数)とtemperature(気温)の散布図を作成してください
ggplot(train,aes(x= temperature,y=y))+
  geom_point() +
  labs(x="temperature ",y="y")

#販売数とtemperature の回帰直線の当てはめ
ggplot(train,aes(x= temperature,y=y))+
  geom_point()+
  geom_smooth(method="lm")

# 「月数」情報の抽出
format(train$time,"%m")

# 「月数」情報を変数に格納（month変数を作成）
install.packages("lubridate")
library(lubridate) 
train$month= month(train$time)
train$month=factor(train$month)

# 「年」と「日」情報を抽出
train$year = year(train$time)
train$year = factor(train$year)
train$day = day(train$time)
train$day = factor(train$day)

# y(販売数)とmonth(各月)の散布図を作成してください
ggplot(train,aes(x=month,y=y))+
  geom_point()+
  labs(x="month",y="y")

# y(販売数)とweek(曜日)のboxplotを作成してください
train$week<-factor(train$week,
                   levels=c("月","火","水","木","金"))
ggplot(train,aes(x=week,y=y,fill=week))+
  geom_boxplot()+
  labs(x="week",y="y")+
  theme_gray(base_family = "HiraKakuPro-W3")

# y(販売数)とweather(天気)のboxplotを作成してください
ggplot(train,aes(x=weather,y=y,fill=weather))+
  geom_boxplot()+
  labs(x="天気",y="販売数")+
  theme_gray(base_family = "HiraKakuPro-W3")

# y(販売数)とevent(社内イベントダミー)の箱ひげ図を作成してください
ggplot(train,aes(x=event,y=y,fill=event))+
  geom_boxplot()+labs(x="社内イベントダミー",y="販売数")+
  theme_gray(base_family = "HiraKakuPro-W3")

# y(販売数)とremarks(特記事項)のboxplotを作成してください
ggplot(train,aes(x=remarks,y=y))+
  geom_boxplot()+
  labs(x="remarks",y="販売数")+
  theme_gray(base_family = "HiraKakuPro-W3")

# 販売数とお楽しみメニューの調査
train$group = "not fun"
train$group[train$remarks=="お楽しみメニュー"] = "fun"
train$group = factor(train$group)

#お楽しみメニューの影響？
ggplot(train,aes(x=time,y=y))+
  geom_point()+
  geom_line()+
  geom_point(
    data=train[train$group == "fun",],
    color="red",
    size=3)

# 箱ひげ図によるお楽しみメニュー有無の可視化
ggplot(train,aes(x=group,y=y))+
  geom_boxplot()

#Rによるウィルコクソンの順位和検定
install.packages("exactRankTests", repos="http://cran.ism.ac.jp/")
library(exactRankTests)  # 開発終了しているため「coin」パッケージの使用を促されるが、これ以上開発の余地がないので無視して良い。
# 引用：https://data-science.gr.jp/implementation/ist_r_wilcoxon_rank_sum_test.html
Fun = train %>%
  filter(group=="fun")
NotFun = train %>%
  filter(group== "not fun")
wilcox.exact(Fun$y,NotFun$y,paired=F)

#「お楽しみメニュー」がある日のデータを保存する
write.csv(Fun,"Fun.csv",fileEncoding = "CP932")

#「カレー」という単語を含むデータの抽出
train$group2 = "not curry"
train$group2[
  train$remarks=="お楽しみメニュー" &
    grepl("カレー",train$name)
  ] = "curry"
train$group2<-factor(train$group2)

# 販売数(目的変数)と日数(説明変数)の単回帰モデル
model1 = lm(y ~ time,train)
summary(model1)
# 予測結果の表示
plot(train$time,predict(model1,train),
     col="red",type='l',ylim=c(0,180))
# 実データを重ねて比較
par(new=T)    
plot(train$time,train$y,
     type='l',ylim=c(0,180))

# 説明変数にweek(曜日)を追加
model2 = lm(y ~ time + week,train)
summary(model2)
plot(train$time,predict(model2,train),
     col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train$time,train$y,
     type='l',ylim=c(0,180))

# 説明変数にmonth(月)を追加
model3 = lm(y ~ time + week + month,train)
summary(model3)
plot(train$time,predict(model3,train),
     col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train$time,train$y,
     type='l',ylim=c(0,180))

#説明変数にtemperature(気温)を追加
model4=lm(y~time+week+month+temperature,
          train)
summary(model4)
plot(train$time,predict(model4,train),
     col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train$time,train$y,
     type='l',ylim=c(0,180))


# 説明変数に「お気に入りメニュー」ダミーを追加
model5=lm(y~time+week+month+temperature+group,
          train)
summary(model5)
plot(train$time,predict(model5,train),
     col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train$time,train$y,
     type='l',ylim=c(0,180))

# 説明変数に「お気に入りメニュー：カレー」ダミーを追加
model6 = lm(y ~ time+week+month+temperature+
              group+group2, train)
summary(model6)
plot(train$time,predict(model6,train),
     col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train$time,train$y,
     type='l',ylim=c(0,180))

# 2014年のデータのみでモデル作成
# 2014年のデータのみ抽出
train2 = train %>%
  filter(year=="2014")
# モデル作成
model7=lm(y~time+week+temperature+
            group+group2,train2)
summary(model7)
plot(train2$time,predict(model7,train2),
     col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train2$time,train2$y,
     type='l',ylim=c(0,180))

#testデータの評価
# mac OSの場合
test=read.csv('test.csv',na.strings=c("", "NULL"))
# Windows OSの場合
test=read.csv('test.csv',na.strings=c("", "NULL"),fileEncoding="UTF-8-BOM")

# trainデータと同じデータ構造にする
#datetimeを時間の変数に変換
test$time=as.Date(test$datetime)
#datetimeを月、年の情報を抽出して質的変数に変換
test$month= month(test$datetime)
test$month=factor(test$month)
test$year= year(test$datetime)
test$year= factor(test$year)

#お楽しみメニューに注目した特徴変数を作成
test$group<- "not fun"
test$group[test$remarks=="お楽しみメニュー"]<- "fun"
test$group=factor(test$group)
test$group2 <- "not curry"
test$group2[test$remarks=="お楽しみメニュー" & grepl("カレー",test$name)] <- "curry"
test$group2=factor(test$group2)
#levels(test$month)<-levels(train$month)
#levels(test$year)<-levels(train$year)


#作成したモデルによる予測
model8=lm(y~time+week+temperature+group+group2,train2)
summary(model8)
plot(train2$time,predict(model8,train2),col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train2$time,train2$y,type='l',ylim=c(0,180))
# 作成したモデルによる予測
p=predict(model8,test)
#結果の保存
write.csv(p,"prediction.csv",fileEncoding = "CP932")