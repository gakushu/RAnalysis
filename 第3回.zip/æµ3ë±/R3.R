# 使用するライブラリの読み込み
library(ggplot2)
library(dplyr)
#データをダウンロード
ncbirths = read.csv("ncbirths.csv")
mammals = read.csv("mammals.csv")
mlbBat10 = read.csv("mlbBat10.csv")
bdims = read.csv("bdims.csv")
smoking = read.csv("smoking.csv")
run10 = read.csv("run10.csv")
possum = read.csv("possum.csv")

#ncbirthsに含まれる変数を確認する
str(ncbirths)
names(ncbirths)

# ggplotを使ってweeksとweight変数の関係を可視化してください
ggplot(ncbirths,aes(x=weeks,y=weight))+
  geom_point()

# ggplotを使ってweeksとweight変数の関係を箱ひげ図を使って可視化してください
ggplot(ncbirths,aes(x=weeks,y=weight))+
  geom_boxplot()
ggplot(ncbirths,aes(x=cut(weeks,breaks=5),y=weight))+
  geom_boxplot()

# mammalsデータを利用して、体重（BodyWt）が脳重量（BrainWt）の関数としてどのように変化するかを示す散布図を作成してください。
ggplot(data = mammals, aes(x = BodyWt, y = BrainWt))+
  geom_point()


# mlbBat10を使用して、プレーヤーのスラッギング率（SLG）がオンベース率（OBP）の関数としてどのように変化するかを示す散布図を作成してください。
ggplot(data = mlbBat10, aes(x = OBP, y = SLG)) +geom_point()

#bdimsデータセットを使用して、人の体重（wgt）が身長(hgt)の関数としてどのように変化するかを示す散布図を作成してください。性別の情報は色で区別しましょう。
ggplot(data = bdims, aes(x = hgt, y = wgt, color = factor(sex))) +
  geom_point()

# 喫煙データセットを使用して、平日の喫煙量(amtWeekdays)が年齢(age)の関数としてどのように変化するかを示す散布図を作成してください。
help(smoking)
ggplot(data = smoking, aes(x = age, y = amtWeekdays)) +
  geom_point()

# 変数の変換
ggplot(data = mammals, aes(x = log10(BodyWt), y = log10(BrainWt))) +
  geom_point()

# 異常値の削除
ab_gt_200 <- mlbBat10 %>% 
  filter(AB >= 200)
ggplot(data = ab_gt_200 , aes(x = OBP, y = SLG)) +
  geom_point()

# 陸上選手データの可視化
run10 %>%
  filter(divPlace<=10) %>%
  ggplot(aes(x=age,y=pace,color=gender))+
  geom_point()

# 相関係数の計算
run10 %>%
  filter(divPlace<=10) %>%
  summarize(N=n(),cor(age,pace))

#25才以上
run10 %>%
  filter(divPlace<=10,age>25) %>%
  group_by(gender)%>% 
  summarize(N=n(),cor(age,pace))

#25才以下
run10 %>%
  filter(divPlace<=10,age<25) %>%
  group_by(gender)%>% 
  summarize(N=n(),cor(age,pace))

#cor（）を使用して、ncbirthsデータの赤ちゃんの出生時体重（weight）と母親の年齢（mage）との相関関係を計算してください。この場合、どちらの変数にも欠損データはありません。 欠落していない変数間、出生時体重と妊娠週数との相関を計算しましょう。
cor(ncbirths$weight, ncbirths$mage)
ncbirths %>%
  summarize(N = n(), r = cor(weight, mage))

#cor（）を使用して、ncbirthsデータの赤ちゃんの出生時体重（weight）と母親の妊娠期間（weeks）との相関関係を計算してください。この場合、変数に欠損データがあります。
cor(ncbirths$weight, ncbirths$ weeks, use = "pairwise.complete.obs")
ncbirths %>%
  summarize(N = n(), r = cor(weight, weeks, 
                             use = "pairwise.complete.obs"))

#回帰モデル(手動)
ggplot(possum, aes(x=tailL,y=totalL))+
  geom_point()
#回帰モデル(手動1)
ggplot(possum, aes(x=tailL,y=totalL))+
  geom_point()+
  geom_abline(intercept=0,slope=2.5)
#回帰モデル(手動2)
ggplot(possum, aes(x=tailL,y=totalL))+
  geom_point()+
  geom_abline(intercept=20,slope=1.8)
#回帰モデル(手動3)
ggplot(possum, aes(x=tailL,y=totalL))+
  geom_point()+
  geom_abline(intercept=41.037,slope=1.244)
#回帰モデル(手動4)
ggplot(possum, aes(x=tailL,y=totalL))+
  geom_point()+
  geom_abline(intercept=0,slope=2.5)+
  geom_abline(intercept=20,slope=1.8, color="blue")+
  geom_abline(intercept=41.037,slope=1.244, color="red")


#回帰モデル(自動１)
ggplot(possum, aes(x=tailL,y=totalL))+
  geom_point()+geom_smooth(method=lm)
#回帰モデル(自動２)
ggplot(possum, aes(x=tailL,y=totalL))+
  geom_point()+geom_smooth(method=lm, se=FALSE)

#回帰モデル(設計)
model=lm(totalL~tailL,possum)
print(model)
 
#回帰モデル(予測)
predict(model, data.frame(tailL=40))

#回帰モデルを使って予測する
data=read.csv("house_rent.csv",header=TRUE)
null_model = lm(rent~1, data)
full_model = lm(rent~., data)
step_model = step(null_model, scope = list(lower = null_model, upper = full_model), direction = "forward")
test_data = read.csv("house_rent_test.csv",header=TRUE)
predict(step_model, test_data)